import { d as defineEventHandler, r as readBody, c as createError, e as readJob, i as getArchivePath, j as syncJobStatus } from '../../../nitro/nitro.mjs';
import fs from 'fs/promises';
import fs$1 from 'fs';
import path from 'path';
import archiver from 'archiver';
import 'execa';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const zipSelected_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const jobId = (body == null ? void 0 : body.jobId) ? String(body.jobId) : null;
  const selectedVideoIds = Array.isArray(body == null ? void 0 : body.selectedVideoIds) ? body.selectedVideoIds : [];
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "jobId is required" });
  }
  if (!selectedVideoIds.length) {
    throw createError({ statusCode: 400, statusMessage: "selectedVideoIds is required" });
  }
  const job = await readJob(jobId);
  const selectedVideos = job.videos.filter((video) => selectedVideoIds.includes(video.id) && video.status === "done" && video.filePath);
  if (!selectedVideos.length) {
    throw createError({ statusCode: 400, statusMessage: "No downloaded files available for selected videos" });
  }
  const zipName = `${jobId}-selected.zip`;
  const zipPath = getArchivePath(zipName);
  await fs.mkdir(path.dirname(zipPath), { recursive: true });
  await new Promise((resolve, reject) => {
    const output = fs$1.createWriteStream(zipPath);
    const archive = archiver("zip", { zlib: { level: 9 } });
    output.on("close", () => resolve());
    archive.on("error", reject);
    archive.pipe(output);
    selectedVideos.forEach((video) => {
      const filePath = path.join(process.cwd(), video.filePath);
      archive.file(filePath, { name: `${video.id}.mp4` });
    });
    archive.finalize();
  });
  await syncJobStatus(jobId);
  return { archiveName: zipName };
});

export { zipSelected_post as default };
//# sourceMappingURL=zip-selected.post.mjs.map
