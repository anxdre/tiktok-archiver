import { d as defineEventHandler, c as createError, s as sendStream } from '../../../nitro/nitro.mjs';
import fs$1 from 'fs';
import fs from 'fs/promises';
import path from 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _jobId__get = defineEventHandler(async (event) => {
  const { jobId } = event.context.params || {};
  if (!jobId) throw createError({ statusCode: 400, statusMessage: "jobId required" });
  const archivePath = path.join(process.cwd(), "archives", jobId);
  try {
    await fs.access(archivePath);
  } catch (e) {
    throw createError({ statusCode: 404, statusMessage: "archive not found" });
  }
  const res = event.node.res;
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename="${jobId}.zip"`);
  const stream = fs$1.createReadStream(archivePath);
  return sendStream(event, stream);
});

export { _jobId__get as default };
//# sourceMappingURL=_jobId_.get.mjs.map
