import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { chromium } from 'playwright';
import 'fs/promises';
import 'fs';
import 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const login_post = defineEventHandler(async () => {
  const context = await chromium.launchPersistentContext(
    "./storage/tiktok-profile",
    {
      headless: false
    }
  );
  const page = context.pages()[0];
  await page.goto(
    "https://www.tiktok.com/login"
  );
  return {
    success: true
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
