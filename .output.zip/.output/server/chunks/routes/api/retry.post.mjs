import { d as defineEventHandler, r as readBody, c as createError, e as readJob, u as updateVideos, f as emitProgress, g as updateJob, h as downloadQueue } from '../../nitro/nitro.mjs';
import 'fs/promises';
import 'fs';
import 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const retry_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const jobId = (body == null ? void 0 : body.jobId) ? String(body.jobId) : null;
  const videoIds = Array.isArray(body == null ? void 0 : body.videoIds) ? body.videoIds : null;
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "jobId is required" });
  }
  const job = await readJob(jobId);
  const failedVideos = (job.videos || []).filter((video) => video.status === "failed");
  const videosToRetry = videoIds && videoIds.length ? failedVideos.filter((video) => videoIds.includes(video.id)) : failedVideos;
  if (videosToRetry.length === 0) {
    return { retryCount: 0 };
  }
  await updateVideos(jobId, videosToRetry.map((video) => video.id), { status: "pending", error: null });
  videosToRetry.forEach((video) => {
    emitProgress("videoQueued", {
      jobId,
      videoId: video.id,
      status: "pending",
      progress: 0
    });
  });
  await updateJob(jobId, { status: "processing" });
  await Promise.all(
    videosToRetry.map(
      (video) => downloadQueue.add("video-download", { jobId, video }, {
        jobId: `video-${jobId}-${video.id}`,
        attempts: 5,
        backoff: {
          type: "exponential",
          delay: 3e3
        }
      })
    )
  );
  return { retryCount: videosToRetry.length };
});

export { retry_post as default };
//# sourceMappingURL=retry.post.mjs.map
