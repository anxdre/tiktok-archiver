import { d as defineEventHandler, c as createError, s as sendStream, e as readJob, n as updateVideo } from '../../../../nitro/nitro.mjs';
import fs$1 from 'fs';
import fs from 'fs/promises';
import path from 'path';
import { execa } from 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

function extFromContentType(ct) {
  if (!ct) return ".jpg";
  if (ct.includes("png")) return ".png";
  if (ct.includes("webp")) return ".webp";
  if (ct.includes("gif")) return ".gif";
  return ".jpg";
}
const _videoId__get = defineEventHandler(async (event) => {
  var _a, _b;
  const jobId = (_a = event.context.params) == null ? void 0 : _a.jobId;
  const videoId = (_b = event.context.params) == null ? void 0 : _b.videoId;
  if (!jobId || !videoId) throw createError({ statusCode: 400, statusMessage: "jobId and videoId required" });
  const thumbsDir = path.join(process.cwd(), "downloads", jobId, "thumbs");
  await fs.mkdir(thumbsDir, { recursive: true });
  const candidates = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
  for (const e of candidates) {
    const p = path.join(thumbsDir, `${videoId}${e}`);
    try {
      await fs.access(p);
      const stream2 = fs$1.createReadStream(p);
      return sendStream(event, stream2);
    } catch (e2) {
    }
  }
  let job;
  try {
    job = await readJob(jobId);
  } catch (e) {
    throw createError({ statusCode: 404, statusMessage: "job not found" });
  }
  let video = (job.videos || []).find((v) => String(v.id) === String(videoId));
  if (!video) throw createError({ statusCode: 404, statusMessage: "video not found" });
  if (!video.thumbnail) {
    try {
      const meta = await execa("yt-dlp", ["--skip-download", "--dump-single-json", video.url]);
      const entry = JSON.parse(meta.stdout);
      if (entry && entry.thumbnail) {
        await updateVideo(jobId, video.id, { thumbnail: entry.thumbnail });
        video = { ...video, thumbnail: entry.thumbnail };
      }
    } catch (err) {
    }
  }
  const remote = video.thumbnail;
  if (!remote) {
    throw createError({ statusCode: 404, statusMessage: "thumbnail not available" });
  }
  let res;
  try {
    res = await fetch(remote);
  } catch (err) {
    throw createError({ statusCode: 502, statusMessage: "failed to fetch thumbnail" });
  }
  if (!res.ok || !res.body) {
    throw createError({ statusCode: 502, statusMessage: "failed to fetch thumbnail" });
  }
  const contentType = res.headers.get("content-type") || "";
  const ext = extFromContentType(contentType) || path.extname(new URL(remote).pathname) || ".jpg";
  const savePath = path.join(thumbsDir, `${videoId}${ext}`);
  await new Promise((resolve, reject) => {
    const fileStream = fs$1.createWriteStream(savePath);
    res.body.pipe(fileStream);
    res.body.on("error", reject);
    fileStream.on("finish", resolve);
    fileStream.on("error", reject);
  });
  const stream = fs$1.createReadStream(savePath);
  return sendStream(event, stream);
});

export { _videoId__get as default };
//# sourceMappingURL=_videoId_.get.mjs.map
