import { d as defineEventHandler, c as createError, j as syncJobStatus } from '../../../nitro/nitro.mjs';
import 'fs/promises';
import 'fs';
import 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const _jobId__get = defineEventHandler(async (event) => {
  const { jobId } = event.context.params || {};
  if (!jobId) throw createError({ statusCode: 400, statusMessage: "jobId required" });
  try {
    const job = await syncJobStatus(jobId);
    return job;
  } catch (e) {
    throw createError({ statusCode: 404, statusMessage: "job not found" });
  }
});

export { _jobId__get as default };
//# sourceMappingURL=_jobId_.get.mjs.map
