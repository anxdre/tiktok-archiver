import { d as defineEventHandler, r as readBody, c as createError, a as cancelJobDownloads } from '../../nitro/nitro.mjs';
import 'fs/promises';
import 'fs';
import 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cancelJob_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const jobId = (body == null ? void 0 : body.jobId) ? String(body.jobId) : null;
  if (!jobId) {
    throw createError({ statusCode: 400, statusMessage: "jobId is required" });
  }
  try {
    const cancelled = await cancelJobDownloads(jobId);
    return { cancelled };
  } catch (error) {
    console.error("[cancel-job]", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Unable to cancel job",
      message: error.message || "Internal server error"
    });
  }
});

export { cancelJob_post as default };
//# sourceMappingURL=cancel-job.post.mjs.map
