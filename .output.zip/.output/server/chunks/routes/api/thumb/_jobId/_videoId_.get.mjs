import { d as defineEventHandler, c as createError, s as sendStream, e as readJob, n as updateVideo } from '../../../../nitro/nitro.mjs';
import fs$1 from 'fs';
import fs from 'fs/promises';
import path from 'path';
import { execa } from 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

function extFromContentType(ct) {
  if (!ct) return ".jpg";
  const s = ct.toLowerCase();
  if (s.includes("png")) return ".png";
  if (s.includes("webp")) return ".webp";
  if (s.includes("gif")) return ".gif";
  if (s.includes("jpeg") || s.includes("jpg")) return ".jpg";
  return ".jpg";
}
async function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
const _videoId__get = defineEventHandler(async (event) => {
  var _a, _b;
  const jobId = (_a = event.context.params) == null ? void 0 : _a.jobId;
  const videoId = (_b = event.context.params) == null ? void 0 : _b.videoId;
  if (!jobId || !videoId) throw createError({ statusCode: 400, statusMessage: "jobId and videoId required" });
  const thumbsDir = path.join(process.cwd(), "downloads", jobId, "thumbs");
  await fs.mkdir(thumbsDir, { recursive: true });
  const TTL_MS = 24 * 60 * 60 * 1e3;
  const candidates = [".jpg", ".jpeg", ".png", ".webp", ".gif"];
  for (const e of candidates) {
    const p = path.join(thumbsDir, `${videoId}${e}`);
    try {
      const st = await fs.stat(p);
      const age = Date.now() - (st.mtimeMs || st.ctimeMs || 0);
      if (age > TTL_MS) {
        try {
          await fs.unlink(p);
        } catch (u) {
        }
        continue;
      }
      const stream = fs$1.createReadStream(p);
      return sendStream(event, stream);
    } catch (err) {
    }
  }
  let job;
  try {
    job = await readJob(jobId);
  } catch (err) {
    throw createError({ statusCode: 404, statusMessage: "job not found" });
  }
  if (!job.videos || !Array.isArray(job.videos)) {
    throw createError({ statusCode: 404, statusMessage: "videos not found" });
  }
  let video = job.videos.find((v) => String(v.id) === String(videoId));
  if (!video) throw createError({ statusCode: 404, statusMessage: "video not found" });
  if (!video.thumbnail) {
    try {
      const meta = await execa("yt-dlp", ["--skip-download", "--dump-single-json", video.url]);
      const entry = JSON.parse(meta.stdout || "{}");
      if (entry && entry.thumbnail) {
        await updateVideo(jobId, video.id, { thumbnail: entry.thumbnail });
        video = { ...video, thumbnail: entry.thumbnail };
      }
    } catch (err) {
    }
  }
  const remote = video.thumbnail;
  if (!remote) {
    const placeholder = path.join(process.cwd(), "public", "thumb-placeholder.svg");
    try {
      await fs.access(placeholder);
      return sendStream(event, fs$1.createReadStream(placeholder));
    } catch (e) {
      throw createError({ statusCode: 404, statusMessage: "thumbnail not available" });
    }
  }
  const maxAttempts = 3;
  let attempt = 0;
  let res;
  let lastStatus = 0;
  while (attempt < maxAttempts) {
    attempt += 1;
    try {
      res = await fetch(remote, { headers: { "User-Agent": "Mozilla/5.0" }, redirect: "follow" });
      lastStatus = res.status;
      if (res.ok) break;
      if (res.status === 429 || res.status === 503) {
        const delay = 500 * Math.pow(2, attempt);
        await sleep(delay);
        continue;
      }
      break;
    } catch (err) {
      const delay = 500 * Math.pow(2, attempt);
      await sleep(delay);
      continue;
    }
  }
  if (!res || !res.ok) {
    const placeholder = path.join(process.cwd(), "public", "thumb-placeholder.svg");
    try {
      await fs.access(placeholder);
      return sendStream(event, fs$1.createReadStream(placeholder));
    } catch (e) {
      throw createError({ statusCode: 502, statusMessage: `failed to fetch thumbnail (${lastStatus})` });
    }
  }
  const contentType = res.headers.get("content-type") || "";
  const ext = extFromContentType(contentType) || path.extname(new URL(remote).pathname) || ".jpg";
  const savePath = path.join(thumbsDir, `${videoId}${ext}`);
  try {
    const buf = Buffer.from(await res.arrayBuffer());
    await fs.writeFile(savePath, buf);
  } catch (err) {
    await new Promise((resolve, reject) => {
      const fileStream = fs$1.createWriteStream(savePath);
      if (res.body && typeof res.body.pipe === "function") {
        res.body.pipe(fileStream);
        res.body.on("error", reject);
        fileStream.on("finish", resolve);
        fileStream.on("error", reject);
      } else {
        reject(new Error("response body not streamable"));
      }
    });
  }
  try {
    await updateVideo(jobId, video.id, { thumbnail: video.thumbnail || remote });
  } catch (e) {
  }
  return sendStream(event, fs$1.createReadStream(savePath));
});

export { _videoId__get as default };
//# sourceMappingURL=_videoId_.get.mjs.map
