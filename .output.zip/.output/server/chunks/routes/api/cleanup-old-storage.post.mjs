import { d as defineEventHandler, b as cleanupOldStorage, c as createError } from '../../nitro/nitro.mjs';
import 'fs/promises';
import 'fs';
import 'path';
import 'execa';
import 'archiver';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'bullmq';
import 'ioredis';
import 'ws';
import 'node:url';
import '@iconify/utils';
import 'consola';

const cleanupOldStorage_post = defineEventHandler(async () => {
  try {
    const removed = await cleanupOldStorage();
    return { removed };
  } catch (error) {
    console.error("[cleanup-old-storage]", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Cleanup failed",
      message: String((error == null ? void 0 : error.message) || error || "Internal server error")
    });
  }
});

export { cleanupOldStorage_post as default };
//# sourceMappingURL=cleanup-old-storage.post.mjs.map
